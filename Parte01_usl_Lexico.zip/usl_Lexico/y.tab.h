#ifndef Y_TAB_H
#define Y_TAB_H

typedef struct {
    int posColumna;
    int posFila;
    int intValor;
    char *stringValor;
} YYSTYPE;

#define	ID	                    258
#define COMENTARIO              259
#define TOKEN_INT               260
#define TOKEN_ASIGNACION        261
#define TOKEN_ENTERO            262
#define TOKEN_FINALINSTRUCCION  263
#define TOKEN_PARENTESISIZQ     264
#define TOKEN_PARENTESISDER     265
#define TOKEN_CORCHETEIZQ       266
#define TOKEN_CORCHETEDER       267
#define TOKEN_COMA              268
#define TOKEN_RETURN            269
#define TOKEN_DEF               270
#define TOKEN_DOSPUNTOS         271
#define TOKEN_OPMAS             272
#define TOKEN_OPMENOS           273
#define TOKEN_OPMULTI           274
#define TOKEN_OPDIV             275

extern YYSTYPE yylval;
#endif
