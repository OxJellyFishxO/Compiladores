#include <libfirm/firm.h>

int main() {

    /* Inicializa libFirm */
    firm_init();
    
    /* Crea el grafo FIRM */
    ir_graph *irg = new_ir_graph();

    /* Crea parámetros formales */
    ir_entity *i = new_entity(irg, mode_P, "i");
    ir_entity *k = new_entity(irg, mode_P, "k");

    /* Crea variable local */
    ir_entity *j = new_entity(irg, mode_P, "j");

    /* Bloque de función */
    ir_node *block = get_irg_start_block(irg);

    /* Inicializa j en 1 */
    ir_node *const1 = new_r_Const(irg, mode_P, 1);
    ir_node *init_j = new_r_Assign(block, get_entity_n(j), const1);

    /* j = i + k * j */
    ir_node *i_val = new_r_Proj(block, mode_P, i);
    ir_node *k_val = new_r_Proj(block, mode_P, k); 
    ir_node *j_val = new_r_Proj(block, mode_P, j);
    ir_node *k_mul_j = new_r_Mul(block, k_val, j_val); 
    ir_node *sum = new_r_Add(block, i_val, k_mul_j);
    ir_node *assign = new_r_Assign(block, get_entity_n(j), sum);

    /* return j */
    ir_node *ret_j = new_r_Proj(block, mode_P, j);
    ir_node *ret = new_r_Return(block, ret_j);

    /* Imprime el grafo FIRM */
    dump_ir_graph(irg);

    firm_finish();
}

ir_graph 0x556327d52980
| {
  block 0
  | (Return
  |   (Proj j) 
  |   (Assign 
  |     (Proj j)
  |     (Add
  |       (Proj i)
  |       (Mul 
  |         (Proj k)
  |         (Proj j))
  |     )
  |   )
  |   (Assign
  |     (Proj j) 
  |     (Const[1])
  |   )
}
