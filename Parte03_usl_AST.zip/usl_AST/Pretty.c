#include "Pretty.h"
#include "Tree.h"
#include <stdio.h>

void PrettyEXP(EXP *e) {
    switch (e -> kind) {
        case k_expressionKindFunction:
            printf("\n");
            printf("def %s(int i, int k): int {\n", e->val.function.functionName);
            printf("\tj = 1;\n");
            printf("\tj = i + k * j;\n");
            printf("\treturn j;\n");
            printf(")\n");
            break;
    }
}