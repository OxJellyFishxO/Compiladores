#ifndef TREE_H
#define TREE_H
typedef enum {
    k_expressionKindFunction,
    k_expressionKindParametros,
    k_expressionKindInstruccion,
    k_expressionKindRetorno,
    k_expressionKindOperador,
    k_expressionKindAsignacion,
    k_expressionKindExpresionEntero,
    k_expressionKindAccesoVariable,
    k_expressionKindOperacion,
    k_expressionKindSentencia,
    k_expressionKindSentenciaRetorno,
    k_expressionKindSentenciasConcat,
    k_expressionKindSentencias

} ExpressionKind;

typedef struct EXP EXP;

struct EXP {
    ExpressionKind kind;
    union {
        char *operador;
        char *variableName;
        EXP *exp;
        int entero;
        EXP *exp1;

        struct {
            char *functionName;
            char *parametros;
        } function;

        struct {
            EXP *parametro;
            EXP *siguientesParametros;
        } parametros;

        struct {
            EXP *instrucciones; // Puedes usar una lista o array según tus necesidades
        } instruccion;

        struct {
            EXP *expresion; // Puedes usar una lista o array según tus necesidades
        } retorno;
        
        struct {
            EXP *lhs;
            EXP *rhs;
        } binary;

        struct {
            EXP *expresion;
        } sentencia;

        struct {
            EXP *sentencia;
            EXP *retorno;
        } sentenciaRetorno; 

        struct {
            EXP *sentencia1;
            EXP *sentencia2;
        } sentenciasConcat;

        struct {
            EXP *sentencia;
        } sentencias;
    } val;
};


EXP *makeEXP_KindFunction(char *functionName);
EXP *makeEXP_Parametros(EXP *parametro);
EXP *makeEXP_ParametrosConcat(EXP *parametros, EXP *siguientesParametros);
EXP *makeEXP_Parametro(char *parametroType, char *parametroID);
EXP *makeEXP_Instruccion(EXP *instrucciones);
EXP *makeEXP_Retorno(EXP *expresion);
EXP *makeEXP_Operador(char *operador);
EXP *makeEXP_Asignacion(char *variableName);
EXP *makeEXP_ExpresionEntero(EXP *exp, int entero);
EXP *makeEXP_AccesoVariable(EXP *exp, char *variableName);
EXP *makeEXP_Operacion(EXP *exp1, char *operador);
EXP *makeEXP_Sentencia(EXP *expresion);
EXP *makeEXP_SentenciaRetorno(EXP *sentencia, EXP *retorno);
EXP *makeEXP_SentenciasConcat(EXP *sentencia1, EXP *sentencia2);
EXP *makeEXP_Sentencias(EXP *sentencia);

#endif