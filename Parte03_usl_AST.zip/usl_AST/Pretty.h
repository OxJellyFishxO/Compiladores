#ifndef PRETTY_H
#define PRETTY_H
/**
 * Pretty.h
*/
#include "Tree.h"

void PrettyEXP(EXP *e);

#endif