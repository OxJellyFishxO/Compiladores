#include "util.h"
#include "Tree.h"
#include <string.h>
#include <stdlib.h>

EXP *makeEXP_KindFunction(char *functionName) {
    EXP *e = malloc(sizeof(EXP));
    
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindFunction;
    e->val.function.functionName = strdup(functionName);

    return e;
}

EXP *makeEXP_Parametros(EXP *parametro) {
    EXP *e = malloc(sizeof(EXP));

    e -> kind = k_expressionKindParametros;
    e -> val.parametros.parametro = parametro;
    e -> val.parametros.siguientesParametros = NULL;
    return e;
}

EXP *makeEXP_ParametrosConcat(EXP *parametros, EXP *siguientesParametros) {
    
    if (parametros == NULL) {
        return siguientesParametros;
    }

    EXP *e = parametros;
    
    while (parametros -> val.parametros.siguientesParametros != NULL) {
        parametros = parametros->val.parametros.siguientesParametros;
    }

    parametros -> val.parametros.siguientesParametros = siguientesParametros;
    return e;
}

EXP *makeEXP_Parametro(char *parametroType, char *parametroID) {
    EXP *e = malloc(sizeof(EXP));
    
    e -> kind = k_expressionKindParametros;
    // Aquí podrías almacenar información adicional del parámetro si es necesario.
    return e;
}

EXP *makeEXP_Instruccion(EXP *instrucciones) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindInstruccion;
    e->val.instruccion.instrucciones = instrucciones;

    return e;
}

EXP *makeEXP_Retorno(EXP *expresion) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindRetorno;
    e->val.retorno.expresion = expresion;
    return e;
}

EXP *makeEXP_Operador(char *operador) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindOperador;
    e->val.operador = strdup(operador);

    return e;
}

EXP *makeEXP_Asignacion(char *variableName) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindAsignacion;
    e->val.variableName = strdup(variableName);

    return e;
}

EXP *makeEXP_ExpresionEntero(EXP *exp, int entero) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindExpresionEntero;
    e->val.exp = exp;
    e->val.entero = entero;

    return e;
}

EXP *makeEXP_AccesoVariable(EXP *exp, char *variableName) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindAccesoVariable;
    e->val.exp = exp;
    e->val.variableName = strdup(variableName);

    return e;
}

EXP *makeEXP_Operacion(EXP *exp1, char *operador) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindOperacion;
    e->val.binary.lhs = exp1;
    e->val.binary.rhs = NULL;  // Puedes inicializar con NULL ya que no se proporciona en este caso
    e->val.operador = strdup(operador);

    return e;
}

EXP *makeEXP_Sentencia(EXP *expresion) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindSentencia;
    e->val.sentencia.expresion = expresion;

    return e;
}

EXP *makeEXP_SentenciaRetorno(EXP *sentencia, EXP *retorno) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindSentenciaRetorno;
    e->val.sentenciaRetorno.sentencia = sentencia;
    e->val.sentenciaRetorno.retorno = retorno;

    return e;
}

EXP *makeEXP_SentenciasConcat(EXP *sentencia1, EXP *sentencia2) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindSentenciasConcat;
    e->val.sentenciasConcat.sentencia1 = sentencia1;
    e->val.sentenciasConcat.sentencia2 = sentencia2;

    return e;
}

EXP *makeEXP_Sentencias(EXP *sentencia) {
    EXP *e = malloc(sizeof(EXP));
    if (e == NULL) {
        // Manejo de error: no se pudo asignar memoria
        exit(EXIT_FAILURE);
    }

    e->kind = k_expressionKindSentencias;
    e->val.sentencias.sentencia = sentencia;

    return e;
}
